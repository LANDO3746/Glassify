const { app, BrowserWindow, shell } = require('electron');
const http = require('http'), fs = require('fs'), path = require('path');
const PORT = 8888; // Spotify redirect URI: http://127.0.0.1:8888/

function startServer() {
  return new Promise(resolve => {
    http.createServer((req, res) => {
      res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
      res.end(fs.readFileSync(path.join(__dirname, 'index.html')));
    }).listen(PORT, '127.0.0.1', resolve);
  });
}

app.whenReady().then(async () => {
  await startServer();
  const win = new BrowserWindow({ width: 1100, height: 760, backgroundColor: '#cdb8ff', autoHideMenuBar: true });
  win.loadURL(`http://127.0.0.1:${PORT}/`);
  win.webContents.setWindowOpenHandler(({ url }) => { shell.openExternal(url); return { action: 'deny' }; });
});
app.on('window-all-closed', () => app.quit());
