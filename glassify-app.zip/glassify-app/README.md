# Glassify

## One-time Spotify setup
1. Go to https://developer.spotify.com/dashboard and create an app.
2. Add this Redirect URI exactly: http://127.0.0.1:8888/
3. Copy the Client ID and paste it into index.html: const CLIENT_ID='...';

## Run it
    npm install
    npm start

## Make an installer (.dmg / .exe / .AppImage)
    npm run dist
The installer appears in the dist/ folder.

## No Node? Run it in your browser instead
    python3 -m http.server 8888 --bind 127.0.0.1
Then open http://127.0.0.1:8888/
